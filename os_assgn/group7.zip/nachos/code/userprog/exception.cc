// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#include "console.h"
#include "synch.h"

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//
//enum ExceptionType { NoException,           // Everything ok!
//		     SyscallException,      // A program executed a system call.
//		     PageFaultException,    // No valid translation found
//		     ReadOnlyException,     // Write attempted to page marked 
//					    // "read-only"
//		     BusErrorException,     // Translation resulted in an 
//					    // invalid physical address
//		     AddressErrorException, // Unaligned reference or one that
//					    // was beyond the end of the
//					    // address space
//		     OverflowException,     // Integer overflow in add or sub.
//		     IllegalInstrException, // Unimplemented or reserved instr.
//		     
//		     NumExceptionTypes
//};
//----------------------------------------------------------------------
static Semaphore *readAvail;
static Semaphore *writeDone;
static void ReadAvail(int arg) { readAvail->V(); }
static void WriteDone(int arg) { writeDone->V(); }
void child_function(int);
void
ExceptionHandler(ExceptionType which)
{
	int type = machine->ReadRegister(2);
	int memval, vaddr, printval, tempval, exp;
	int readreg;	
	char filename[100];
	TranslationEntry *entry;
	unsigned int vpn, offset, pageFrame;	

	if(!initializedConsoleSemaphores){
		readAvail = new Semaphore("read avail", 0);
		writeDone = new Semaphore("write done", 1);
		initializedConsoleSemaphores=true;
	}
	Console *console = new Console(NULL, NULL, ReadAvail, WriteDone, 0);

	if ((which == SyscallException) && (type == SC_Halt)) {
		DEBUG('a', "Shutdown, initiated by user program.\n");
		interrupt->Halt();
	}
	else if ((which == SyscallException) && (type == SC_PrintInt)) {
		printval = machine->ReadRegister(4);
		if (printval == 0) {
			writeDone->P() ;
			console->PutChar('0');
		}
		else {
			if (printval < 0) {
				writeDone->P() ;
				console->PutChar('-');
				//writeDone->P() ;
				printval = -printval;
			}
			tempval = printval;
			exp=1;
			while (tempval != 0) {
				tempval = tempval/10;
				exp = exp*10;
			}
			exp = exp/10;
			while (exp > 0) {
				writeDone->P() ;
				console->PutChar('0'+(printval/exp));
				//writeDone->P() ;
				printval = printval % exp;
				exp = exp/10;
			}
		}
		// Advance program counters.
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
	}
	else if ((which == SyscallException) && (type == SC_PrintChar)) {
		writeDone->P() ;
		console->PutChar(machine->ReadRegister(4));   // echo it!
		//writeDone->P() ;        // wait for write to finish
		// Advance program counters.
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
	}
	else if ((which == SyscallException) && (type == SC_PrintString)) {
		vaddr = machine->ReadRegister(4);
		machine->ReadMem(vaddr, 1, &memval);
		while ((*(char*)&memval) != '\0') {
			writeDone->P() ;
			console->PutChar(*(char*)&memval);
			//writeDone->P() ;
			vaddr++;
			machine->ReadMem(vaddr, 1, &memval);
		}
		// Advance program counters.
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
	}

	else if((which == SyscallException) && (type == SC_GetReg)){
		readreg = machine->ReadRegister(4);
		readreg = machine->ReadRegister(readreg);
		machine->WriteRegister(2,readreg);
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);	
	}


	else if((which == SyscallException) && (type == SC_GetPA)){
		readreg = machine->ReadRegister(4);
		vpn = readreg / PageSize;
		offset =  readreg % PageSize;
		if (vpn >= machine->pageTableSize) 	
			machine->WriteRegister(2,-1);

		else
		{
			entry = &(machine->pageTable[vpn]);
			entry->use = TRUE;
			pageFrame = entry->physicalPage;
			if (pageFrame >= NumPhysPages) 
				machine->WriteRegister(2,-1);
			else
				machine->WriteRegister(2,pageFrame * PageSize + offset);	
		}
		printf("virtual: %d\n", readreg);	
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
	}

	else if((which == SyscallException) && (type == SC_GetPID)){
		machine->WriteRegister(2,currentThread->call_pid());
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
	}

	else if((which == SyscallException) && (type == SC_GetPPID)){
		machine->WriteRegister(2,currentThread->call_ppid());
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);

	}

	else if((which == SyscallException) && (type == SC_Time)){
		machine->WriteRegister(2,stats->totalTicks);
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
	}


	else if((which == SyscallException) && (type == SC_Sleep)){
		readreg = machine->ReadRegister(4);
		if(!readreg){
			currentThread->Yield();
		}

		else{
			readreg = stats->totalTicks + readreg;
			scheduler->sleeping_queue(readreg);
			interrupt->SetLevel(IntOff);
			currentThread->Sleep();
			interrupt->SetLevel(IntOn);
		}

		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);

	}

	else if((which == SyscallException) && (type == SC_Yield)){
		Thread *nextThread;
		IntStatus oldLevel = interrupt->SetLevel(IntOff);
		nextThread = scheduler->FindNextToRun();
		if (nextThread != NULL) {
			scheduler->ReadyToRun(currentThread);
			scheduler->Run(nextThread);
		}
		(void) interrupt->SetLevel(oldLevel);
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
	}

	else if((which == SyscallException) && (type == SC_Exec)){
		int i=0;
		vaddr = machine->ReadRegister(4);
		machine->ReadMem(vaddr, 1, &memval);

		AddrSpace *space, *dltspace;
		while ((*(char*)&memval) != '\0') {
			filename[i++]= (*(char*)&memval);
			vaddr++;
			machine->ReadMem(vaddr, 1, &memval);	
		}
		filename[i]='\0';
		OpenFile *executable = fileSystem->Open(filename);
		if (executable == NULL) {
			printf("Unable to open file %s\n", filename);
			return;
		}
		space = new AddrSpace(executable);

		dltspace = currentThread->space;
		//printf("\ndltspace->%d\n",dltspace->getphys());
		currentThread->space = space;
	//	printf("\ncthead->%d\n",currentThread->space->getphys());
	//	printf("\ncthread size->%d\n",currentThread->space->getnum());

		dltspace->~AddrSpace(); 
		delete executable;                  // close file
		space->InitRegisters();             // set the initial register values
		space->RestoreState(); 
		machine->Run();
		ASSERT(FALSE);
	}


	else if((which == SyscallException) && (type == SC_Fork)){

		// Advance program counters.
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
		
		Thread *newThread = new Thread("child");
		newThread->space = new AddrSpace();
		newThread->SaveUserState(); 
		newThread->set2Register();
		//printf("\n\tcalling fork\n");
		machine->WriteRegister(2,newThread->call_pid());
		newThread->Fork(child_function,0);
	}


	else if((which == SyscallException) && (type == SC_Join)){
		readreg = machine->ReadRegister(4);
		int child = currentThread->searchforchild(readreg);
		 DEBUG('s', "child value for %d\n",child);
		if(child == -2)						// child doesnot exist
			machine->WriteRegister(2,-1);
		else
		{
			if(child != -1)
				machine->WriteRegister(2,child);

			else
				{
				scheduler->join_queue(readreg);
				interrupt->SetLevel(IntOff);
				currentThread->Sleep();
				interrupt->SetLevel(IntOn);
				}
		}
		machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
		machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
		machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
	}

	else if((which == SyscallException) && (type == SC_Exit)){

		readreg = machine->ReadRegister(4);
		running_threads--;
		printf("\n|------------- Exiting thread with PID: %d  Exit Code: %d-----------------|\n\n",currentThread->call_pid(), readreg);
		if(running_threads==0)
			interrupt->Halt();

		else
		{
			if(currentThread->call_pid()!=0)
			{
				currentThread->parentupdate(readreg);
				scheduler->wakeup_parent(currentThread->call_pid());
			}
			currentThread->exitingthread();
		}
	}

	else {
		printf("Unexpected user mode exception %d %d\n", which, type);
		ASSERT(FALSE);
	}
}

void child_function(int x)
{
	if (threadToBeDestroyed != NULL) {
		delete threadToBeDestroyed;
		threadToBeDestroyed = NULL;
	}

#ifdef USER_PROGRAM
	if (currentThread->space != NULL) {         // if there is an address space
		currentThread->RestoreUserState();     // to restore, do it.
		currentThread->space->RestoreState();
	}
#endif
	machine->Run();

}

